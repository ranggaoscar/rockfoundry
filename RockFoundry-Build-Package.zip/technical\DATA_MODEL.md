# Data Model

| Table | Key fields | Notes |
|---|---|---|
| users | id, email, created_at | Account identity |
| workspaces | id, owner_user_id, name | One personal workspace in MVP |
| projects | id, workspace_id, name, status, readiness_level | Ownership boundary |
| project_states | project_id, version, state_json, created_at | Append-only canonical snapshots |
| interview_rounds | id, project_id, state_version, status | Up to 3 questions |
| questions | id, round_id, prompt, choices_json, rationale | Persist generation result |
| answers | id, question_id, answer_json, answered_at | Input evidence |
| decisions | id, project_id, key, value_json, source, status | Accepted/rejected/needs-review |
| contradictions | id, project_id, rule_id, severity, status | Open/resolved/waived |
| references | id, project_id, type, url, status | URL or public GitHub repo |
| exports | id, project_id, state_version, storage_key, expires_at | ZIP tracks snapshot |
| subscriptions | id, workspace_id, plan, starts_at, ends_at, status | Entitlement source |
| payment_invoices | id, workspace_id, provider_ref, amount_idr, status, expires_at | QRIS payment request |
| payment_events | id, provider_event_id, payload_hash, processed_at | Idempotency and audit |

`project_states.state_json` conforms to `PROJECT_MANIFEST.json`; every accepted decision increments the state version.
