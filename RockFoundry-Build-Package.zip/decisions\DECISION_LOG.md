# Decision Log

| ID | Decision | Why | Status |
|---|---|---|---|
| D-001 | Canonical structured project state renders all docs. | Prevent conflicting Markdown. | Accepted |
| D-002 | Adaptive questions are graph-guided and capped at 3 per round. | Avoid generic forms and cognitive overload. | Accepted |
| D-003 | MVP stops before code generation/deployment. | Keep the product boundary clear. | Accepted |
| D-004 | Community is self-hosted BYOK; Cloud Starter is Rp49,000/30 days. | Open core plus convenience. | Accepted |
| D-005 | 9Router remains server-internal routing only. | Do not share consumer subscriptions or leak credentials. | Accepted |
| D-006 | First payment method is QRIS via SumoPod adapter. | Fits Indonesian one-term access; keeps provider replaceable. | Accepted |
| D-007 | Only public URLs and public GitHub repos are analyzed. | Limit security and privacy risk. | Accepted |
