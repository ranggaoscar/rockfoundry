# System Architecture

## Recommended MVP shape

Use a single web application with a server API, relational database, object storage for exports, and a background worker. Keep product rules in the application; provider and payment integrations sit behind small adapters.

```text
Browser
  │ HTTPS
Web app / server API ── PostgreSQL (project state, billing, audit metadata)
  │        │
  │        ├── Worker queue ── URL/repo fetch + analysis + ZIP rendering
  │        ├── Object storage ── temporary export ZIPs
  │        ├── Payment adapter ── SumoPod QRIS
  │        └── AI gateway ── 9Router ── approved provider APIs
  └── Auth provider / session store
```

## Trust boundaries

The browser never receives managed provider credentials, payment secrets, or 9Router admin access. The server validates ownership before every project, reference, export, or billing action.

## Key design choices

- Store canonical state as JSONB with normalized project ownership and audit tables.
- Run URL/repo analysis asynchronously with strict network and size limits.
- Render Markdown deterministically from state; use AI only for analysis and drafting, never as the final source of truth.
- Use a payment-provider interface, but implement only SumoPod first.
