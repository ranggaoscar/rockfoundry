# Deployment Plan

Deploy a single production environment first: web app/API, PostgreSQL, worker, object storage, and managed secrets.

## Required configuration

- Auth/session secret and allowed origin.
- Database connection and migration command.
- Object-storage credentials and export lifecycle policy.
- AI gateway/provider credentials and per-plan budgets.
- SumoPod API credentials, webhook verification secret, and public webhook URL.
- Observability DSN and alert destination.

## Release process

1. Apply migrations in a backup-capable environment.
2. Deploy app and worker from the same version.
3. Run authenticated smoke flow with a test project.
4. Confirm webhook signature rejection and a sandbox payment success.
5. Monitor errors, queue age, export failures, and payment processing for 24 hours.

Self-hosted deployment ships with BYOK only and no managed billing credentials.
